<?php
    $page = "item";
    include('home-header.php'); 
    if(empty($_SESSION["username"])) header("Location: index.php");
    $username= $_SESSION['username']."</br>";
    $user_id= $_SESSION['user_id'];
   
    $xml = simplexml_load_file("admin/product.xml");
    $products = array(); 
    foreach ($xml->product as $product) { 
       $products[] = array(
            'prod_id'=>(string)$product->prod_id,
            'prod_name'=>(string)$product->prod_name,
            'prod_brand'=>(string)$product->prod_brand,
            'prod_category'=>(string)$product->prod_category,
            'prod_price'=>(string)$product->prod_price,
            'prod_quantity'=>(string)$product->prod_quantity,
            'prod_path'=>(string)$product->prod_path,
            'prod_des'=>(string)$product->prod_des,
        );
    }
   
    $totalProducts = count($products);
    $tt=$totalProducts;
    if($totalProducts != 0){
        for($i = 0 ; $i < $totalProducts ; $i++){
            if($xml->product[$i]->prod_category ==  "Men" ){
                $mens[] = array(
                    'prod_id'=>(string)$xml->product[$i]->prod_id,
                    'prod_name'=>(string)$xml->product[$i]->prod_name,
                    'prod_brand'=>(string)$xml->product[$i]->prod_brand,
                    'prod_category'=>(string)$xml->product[$i]->prod_category,
                    'prod_price'=>(string)$xml->product[$i]->prod_price,
                    'prod_quantity'=>(string)$xml->product[$i]->prod_quantity,
                    'prod_path'=>(string)$xml->product[$i]->prod_path,
                    'prod_des'=>(string)$xml->product[$i]->prod_des,
                );
            }
        }
    
        for($i = 0 ; $i < $totalProducts ; $i++){
            if($xml->product[$i]->prod_category ==  "Women" ){
                $womens[] = array(
                    'prod_id'=>(string)$xml->product[$i]->prod_id,
                    'prod_name'=>(string)$xml->product[$i]->prod_name,
                    'prod_brand'=>(string)$xml->product[$i]->prod_brand,
                    'prod_category'=>(string)$xml->product[$i]->prod_category,
                    'prod_price'=>(string)$xml->product[$i]->prod_price,
                    'prod_quantity'=>(string)$xml->product[$i]->prod_quantity,
                    'prod_path'=>(string)$xml->product[$i]->prod_path,
                    'prod_des'=>(string)$xml->product[$i]->prod_des,
                );
            }
        }

        $totalProducts = count($mens);
        $perPage = 6;
        $page = isset($_GET['page']) && ($page = intval($_GET['page'])) > 0 ?  $page : 1;
        $start = ($page - 1) * $perPage;
        $end = $start + $perPage;
        $menss = array();
        for ($a=$start; $a<$end; ++$a) { 
            if (isset($mens[$a])) { 
            $menss[] = $mens[$a];                 
            }
        }
        $pages = ceil($totalProducts / $perPage);

        $totalProducts2 = count($womens);
        $perPage2 = 6;
        $page2 = isset($_GET['page']) && ($page2 = intval($_GET['page'])) > 0 ?  $page2 : 1;
        $start2 = ($page2 - 1) * $perPage2;
        $end2 = $start2 + $perPage2;
        $womenss = array();
        for ($a=$start2; $a<$end2; ++$a) { 
            if (isset($womens[$a])) { 
            $womenss[] = $womens[$a];                 
            }
        }
        $pages2 = ceil($totalProducts2 / $perPage2);
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./products.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">  
</head>
<body>
    <div class="container-fluid d-flex flex-column   align-items-center justify-content-center p-5 ">
        <div style="width:75%;display:flex;align-items:center;" class="category-container">
                <div class="men">
                    <h1>Men's</h1>
                </div>
                <div style="margin-left:78%;" class="view">
                <a class='btn btn-info text-white fw-bold font-monospace' href='products.php?category=Men'>VIEW ALL</a>
            
                </div>
        </div>
        <div class="product-container">
            <?php
                $countMen=0;
                foreach($menss as $men){
                    echo " <a style='text-decoration:none;color:black;'href='viewProduct.php?prod_id=".$men['prod_id']."'>
                        <div class='product' title='".$men['prod_name']."'>
                           
                            <span class='prod-name'>".$men['prod_name']."</span>
                            <div class='image-container mb-2'>
                                <img class='i' src='".$men['prod_path']."'>
                            </div>
                                <div class='info-container'>
                                    <span>Price: </span>
                                    <p id='".$countMen."' class='price' >".$men['prod_price']."</p>
                                </div>
                                <div class='info-container'>
                                    <span>Quantity: </span>
                                    <p class='price' >".$men['prod_quantity']."</p>
                                </div>
                                <div class='button-container mt-3 mb-2'>
                                    <form class='addCart' action='addCart.php'>
                                        <input type='hidden' name='prod_xid' value='".$men['prod_id']."'>
                                        <input type='hidden' name='user_id' value='".$user_id."'>
                                        <input type='hidden' name='cart_quantity' value='1'>
                                        <input type='hidden' name='prod_available' value='".$men['prod_quantity']."'>
                                        <input type='hidden' name='prod_price' value='".$men['prod_price']."'>
                                        <input type='hidden' name='prod_path' value='".$men['prod_path']."'>
                                        <input type='hidden' name='prod_name' value='".$men['prod_name']."'>
                                        <button class='btn-addcart' type='submit' title='Add to Cart' name='add-cart'>
                                          <i class='fas fa-cart-plus'></i>
                                        </button>
                                    </form>
                                    <form class='addWish' action='addWish.php'>
                                        <input type='hidden' name='prod_xid' value='".$men['prod_id']."'>
                                        <input type='hidden' name='user_id' value='".$user_id."'>
                                        <input type='hidden' name='cart_quantity' value='1'>
                                        <input type='hidden' name='prod_available' value='".$men['prod_quantity']."'>
                                        <input type='hidden' name='prod_price' value='".$men['prod_price']."'>
                                        <input type='hidden' name='prod_path' value='".$men['prod_path']."'>
                                        <input type='hidden' name='prod_name' value='".$men['prod_name']."'>
                                        <button class='btn-addwish' type='submit' title='Add to Wish List' name='add-wish'>
                                            <i class='fas fa-heart'></i>
                                        </button>
                                    </form>
                                </div>
                                
                        </div>
                        </a>
                    ";
                    $countMen++;
                }
            ?>
        </div>

        <div style="margin-top:50px; width:75%;display:flex;align-items:center;" class="category-container">
                <div class="men">
                    <h1>Women's</h1>
                </div>
                <div style="margin-left:70%;" class="view">
                <a class='btn btn-info text-white fw-bold font-monospace' href='products.php?category=Women'>VIEW ALL</a>
                </div>
        </div>
        <div class="product-container">
            <?php
                $counterWom=-1;
                foreach($womenss as $men){
                    echo " <a style='text-decoration:none;color:black;'href='viewProduct.php?prod_id=".$men['prod_id']."'>
                        <div class='product'>
                        <span class='prod-name'>".$men['prod_name']."</span>
                            <div class='image-container mb-2'>
                                <img class='i' src='".$men['prod_path']."'>
                            </div>
                              
                                <div class='info-container'>
                                        <span>Price: </span>
                                        <p id='".$counterWom."' class='price' >".$men['prod_price']."</p>
                                    </div>
                                    <div class='info-container'>
                                        <span>Quantity: </span>
                                        <p class='price' >".$men['prod_quantity']."</p>
                                    </div>
                                <div class='button-container  mt-3 mb-2'>
                                    <form class='addCart' action='addCart.php'>
                                        <input type='hidden' name='prod_xid' value='".$men['prod_id']."'>
                                        <input type='hidden' name='user_id' value='".$user_id."'>
                                        <input type='hidden' name='cart_quantity' value='1'>
                                        <input type='hidden' name='prod_available' value='".$men['prod_quantity']."'>
                                        <input type='hidden' name='prod_price' value='".$men['prod_price']."'>
                                        <input type='hidden' name='prod_path' value='".$men['prod_path']."'>
                                        <input type='hidden' name='prod_name' value='".$men['prod_name']."'>
                                        <button class='btn-addcart' type='submit' title='Add to Cart' name='add-cart'>
                                          <i class='fas fa-cart-plus'></i>
                                        </button>
                                    </form>
                                    <form class='addWish' action='addWish.php'>
                                        <input type='hidden' name='prod_xid' value='".$men['prod_id']."'>
                                        <input type='hidden' name='user_id' value='".$user_id."'>
                                        <input type='hidden' name='cart_quantity' value='1'>
                                        <input type='hidden' name='prod_available' value='".$men['prod_quantity']."'>
                                        <input type='hidden' name='prod_price' value='".$men['prod_price']."'>
                                        <input type='hidden' name='prod_path' value='".$men['prod_path']."'>
                                        <input type='hidden' name='prod_name' value='".$men['prod_name']."'>
                                        <button class='btn-addwish' type='submit' title='Add to Wish List' name='add-wish'>
                                            <i class='fas fa-heart'></i>
                                        </button>
                                    </form>
                                </div>
                        </div>
                        </a>
                    ";
                    $counterWom--;
                }
            }   
            ?>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            var x = <?php echo $totalProducts?>;
            var m = -Math.abs(<?php echo $totalProducts2;?>);
         
            var formatter = new Intl.NumberFormat('en-PH', {
                style: 'currency',
                currency: 'PHP',
            });
            for(var i = 0 ; i < x ; i++){
                $("#"+i).html(formatter.format(parseInt($("#"+i).html())));
                
            }
          
            for(var ik = -1 ; ik >= m ; ik--){
              
                $("#"+ik).html(formatter.format(parseInt($("#"+ik).html())));

            }
         
            $(".product").on('click',function(){
                var  form = $(this).find('.view-prod');
                form.submit();
            });
            $(".addCart").submit(function(e) {
                e.preventDefault(); // avoid to execute the actual submit of the form.

                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    complete: function(data)
                    {
                        if(data.responseText === "save\t"){
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Item has been added to your shopping cart',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        } else if(data.responseText === "found\t"){
                        Swal.fire({ 
                            icon:'info',
                            title:'Online Shop',
                            text: 'This product is already in your shopping .',  
                            showConfirmButton: false,  
                            timer: 2000
                        })
                    }
                }
                });
            });

            $(".addWish").submit(function(e) {

                e.preventDefault(); // avoid to execute the actual submit of the form.

                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    complete: function(data)
                    {
                        if(data.responseText === "save\t"){
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Item has been added to your shopping wishlist',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        } else if(data.responseText === "found\t"){
                            Swal.fire({ 
                                icon:'info',
                                title:'Online Shop',
                                text: 'This product is already in your shopping wishlist.',  
                                showConfirmButton: false,  
                                timer: 2000
                            })
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>
