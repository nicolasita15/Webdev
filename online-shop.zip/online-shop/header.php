
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        html,body{
            margin:0;
            padding:0;
            overflow: hidden;
            box-sizing: border-box;
        }
     
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
     <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">  
</head>
<body>
    <div class="container-fluid">
        
        <div class="row px-5 py-2 border-bottom bg-info">
            <button style="font-size:24px;" class="fw-bold col-1 p-0 m-0 col-1 btn-outline-light font-monospace btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    JJJRC
            </button>
           <div class="col-11 d-flex flex-row justify-content-end btn-container">
               
                <button style="font-size:14px;" class="btn-outline-light m-0 font-monospace btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    LOGIN
                </button>
                <button  style="font-size:14px;" class='ms-2 btn-outline-light m-0 font-monospace btn' data-bs-toggle="modal" data-bs-target="#registerModal">
                    SIGN UP
                </button>
           </div>
        </div>
    </div>
    <?php
        include('body.php');
    ?>
</body>
</html>