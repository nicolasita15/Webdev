<?php
    include("home-header.php");
    $transaction = simplexml_load_file("transaction.xml");
    $products = simplexml_load_file("admin/product.xml");
    $xml = new DOMDocument( "1.0");
    $xml->load("transaction.xml");
    $xml2 = new DOMDocument( "1.0");
    $xml2->load("admin/product.xml");
    $len_product = $xml2->getElementsByTagName("products")[0]->getElementsByTagName('product')->length;
    $len_transaction = $xml->getElementsByTagName("transactions")[0]->getElementsByTagName('transaction')->length;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
</head>
<body>
<div style='height:auto;' class="mt-5 container-fluid pb-5 d-flex flex-column align-items-center  ">
  
  <div class="product-container">
      <?php
       for($i = 0 ; $i < $len_transaction;  $i++){
 
          for($x = 0 ; $x < $len_product ; $x++){
             // echo strval($products->product[$x]->prod_id)." == ".strval($transaction->transaction[$i]->prod_id)."<br>";
            if($transaction->transaction[$i]->user_id == $_SESSION['user_id'] && strval($products->product[$x]->prod_id) === strval($transaction->transaction[$i]->prod_id)){
                echo "
                    <div class='product'>
                        <label class='fw-bold font-monospace ms-2 text-truncate d-inline-block' style='width:220px;'>".$products->product[$x]->prod_name."</label>
                        <div class='image-container'>
                            
                            <img class='i' src='".$products->product[$x]->prod_path."'>
                        </div>
                        <div class='d-flex info-container'>
                            <span>Unit Price:</span>
                            <p id='p".$i."' class='price'>".$products->product[$x]->prod_price."</p>
                        </div>
                        <div class='info-container'>
                            <span>Quantity:</span>
                            <p class='price'>".$transaction->transaction[$i]->quantity."</p>
                        </div>  
                        <div class='info-container'>
                            <span>Total:</span>
                            <p id='p2".$i."' class='price'>".intval($transaction->transaction[$i]->quantity)*intval($products->product[$x]->prod_price)."</p>
                        </div> 
                    </div>
                    ";
            }else{
                
            }
          }
      }
      ?>
  </div> 
</div>

    
<script>
    $(document).ready(function(){
        var len = <?php echo $len_transaction;?>;
        var formatter = new Intl.NumberFormat('en-PH', {
                style: 'currency',
                currency: 'PHP',
            });
          
        for(var i = 0 ; i < len ; i++){
            $("#p"+i).html(formatter.format(parseInt($("#p"+i).html())));  
            $("#p2"+i).html(formatter.format(parseInt($("#p2"+i).html())));                
        }
        $("#user").removeClass('btn-info-outline');
         $("#user").addClass('btn-info text-white');
    });
</script>
</body>
</html>


<!-- echo "
                    <div class='product'>
                        <label class='fw-bold font-monospace ms-2 text-truncate d-inline-block' style='width:220px;'>".$product->product[$x]->prod_name."</label>
                        <div class='image-container'>
                            <img class='i' src='".$product->product[$x]->path."'>
                        </div>
                        <div class='info-container'>
                            <span>Unit Price:</span>
                            <p id='p".$i."' class='price'>".$product->product[$x]->unit_price."</p>
                        </div>
                        <div class='info-container'>
                            <span>Quantity:</span>
                            <p class='price'>".$transaction->transaction[$i]->quantity."</p>
                        </div>  
                             
                    </div>
                    "; -->