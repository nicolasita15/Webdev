<?php
	$xml = new DOMDocument();
	$xml->formatOutput = true;
	$xml->preserveWhiteSpace = false;
	$xml->load("accounts.xml");
	$newAccount =  $xml -> getElementsByTagName('account');
    
	$fullname = $_POST["fullname"];
	$address = $_POST["address"];
	$email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $contact = $_POST['contact'];
    $user_id = $newAccount->length;
	$newAccount = $xml -> createElement('account');
    $newAccount -> appendChild($xml -> createElement('user_id',$user_id++));
	$newAccount -> appendChild($xml -> createElement('fullname',$fullname));
	$newAccount -> appendChild($xml -> createElement('email',$email));
	$newAccount -> appendChild($xml -> createElement('address',$address));
	$newAccount -> appendChild($xml -> createElement('contact',$contact));
    $newAccount -> appendChild($xml -> createElement('username',$username));
	$newAccount -> appendChild($xml -> createElement('password',$password));
	$xml -> getElementsByTagName('accounts') -> item(0) -> appendChild($newAccount);
	$test = $xml -> save('accounts.xml');
?>