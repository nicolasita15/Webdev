<?php
    $page ="checkout";
    include('home-header.php');
    $x = $_GET['id'];
    $sxml = simplexml_load_file('cart.xml');
   
	$index = 0;
    $new_id = str_replace(array( '\'', '"',
    ',' , ';', '<', '>' ), ' ',$x);
    $new="";
    $xml = new DOMDocument( "1.0");
    $xml->load("cart.xml");
    $len_cart = $xml->getElementsByTagName("carts")[0]->getElementsByTagName('cart')->length;
    echo "before ".$new_id."<br>";;
    $new_id = preg_replace('/\s+/', '', $new_id);
    echo "after ".$new_id;
    $id_array=array();
    // for($i = 0 ; $i < strlen($new_id) ; $i++){
    //     array_push();
    // }
    $finalTotal=0;
    $allQty="";
    $itemCounter=0;

    $fullName="";
    $adddress="";
    $contact="";
    $accounts = simplexml_load_file('accounts.xml');

    foreach($accounts as $account) {
        if($account->user_id == $_SESSION['user_id']){
            $fullName = $account->fullname;
            $adddress = $account->address;
            $contact = $account->contact;
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="checkout.css">
</head>
<body>
    <div class="container-fluid justify-content-center d-flex p-5" >
        <div class="row d-flex justify-content-center">
            <div class="col-6 dev_address p-3">
                <h3>
                    <button id="de" class='text-white btn btn-info'> <i class="far fa-user"></i></button>
                    Delivery Address
                    <button id="a" class='btn btn-danger'><i class="fal fa-edit"></i></button>
                    <button id="b" class='btn btn-outline-danger'><i class="fal fa-save"></i></button>
                </h3>
                <input disabled type="text" id="n" class='mb-2' value='<?php echo $fullName;?>' placeholder="Name">
                <input disabled type="text" id="d" class='mb-2' value='<?php echo $adddress;?>' placeholder="Delivery Address">
                <input disabled type="text" id="c" class='mb-2' value='<?php echo $contact;?>' placeholder="Contact number">
            </div>
            <div class="col-6 payment_section p-3" >
                <h3>Shipping Option</h3>
                <div class="st-dev">
                   <span>Standard Deliver:</span>
                   <p id="ship-fee">50</p>
                </div>
                <div class="st-dev">
                   <span>Recieve by:</span>
                   <p id='dev-date'>July 11 - July 15</p>
                </div>
                <p>COD is supported</p>
        </div>

        <div class="row">
            <div class="col-8 product-container custom__grid">
                <?php
                    for($i = 0 ; $i < strlen($new_id);  $i++){
                        for($x = 0 ; $x < $len_cart ; $x++){
                            echo $sxml->cart[$x]->prod_id ." == ". $new_id[$i]."new id here" ." && ". $sxml->cart[$x]->user_id. " == ". $_SESSION['user_id']."<br>";
                            if($sxml->cart[$x]->prod_id == $new_id[$i] && $sxml->cart[$x]->user_id == $_SESSION['user_id']){
                                $itemCounter++;
                                $totalEach=intval($sxml->cart[$x]->quantity)*intval($sxml->cart[$x]->unit_price);
                                $finalTotal = intval($finalTotal)+$totalEach;
                                $allQty = $allQty.$sxml->cart[$x]->quantity;
                                echo "
                                    <div class='product'>
                                        <span  class='fw-bold font-monospace ms-2 text-center text-truncate d-inline-block' style='width:220px;'>".$sxml->cart[$x]->prod_name."</span>
                                            <div class='image-container'>
                                                <img class='i' src='".$sxml->cart[$x]->path."'>
                                            </div>
                                            <div class='info-container'>
                                                <span>Unit Price:</span>
                                                
                                                <p id='p".$i."' class='price'>".$sxml->cart[$x]->unit_price."</p>
                                            </div>
                                            <div class='info-container'>
                                            <span>Order:</span>
                                            <p class='price'>".$sxml->cart[$x]->quantity."</p>
                                        </div>  
                                        <div class='info-container'>
                                            <span>Total:</span>
                                            <p id='p2".$i."' class='price'>".intval($sxml->cart[$x]->quantity)*intval($sxml->cart[$x]->unit_price)."</p>
                                        </div> 
                                    </div>
                                
                                ";
                            } 
                            
                        }
                    }
                ?>
            </div>
            <div  class="col-2 __cutom_info">
                <h5>Payment Method</h5>
                <div class="info-container">
                    <span>Option:</span>
                    <p>Cash on Delivery </p>
                </div>
                <div class="info-container">
                    <span>Shipping Fee:</span>
                    <p id="ship-fee2">50</p>
                </div>
                <div class="info-container">
                    <span>Total of Items: </span>
                    <p><?php echo $itemCounter;?></p>
                </div>
                <div class="info-container">
                    <span>Subtotal: </span>
                    <p id="sub"><?php echo $finalTotal;?></p>
                </div>
                <div class="info-container">
                    <span>Final Total: </span>
                    <p id="final"><?php echo $finalTotal+50;?></p>
                </div>
                <div class="info-container">
                    <form action="checkoutProcess.php" class='checkout'>
                        <input type="hidden" name='new_id' value="<?php echo $new_id?>">
                        <input type="hidden" name='all_qty' value="<?php echo $allQty?>">
                        <button type='submit' name='place_order' class='btn btn-outline-danger'>
                            PLACE ORDER
                        </button>
                    </form>
                </div>
            </div>
        </div>   
    </div>
    <script>
        $(document).ready(function(){
            $("#b").hide();
            var len = <?php echo strlen($new_id);?>;
            var formatter = new Intl.NumberFormat('en-PH', {
                style: 'currency',
                currency: 'PHP',
            });
            $("#ship-fee").html(formatter.format(parseInt($("#ship-fee").html())));
            $("#ship-fee2").html(formatter.format(parseInt($("#ship-fee2").html())));
            $("#sub").html(formatter.format(parseInt($("#sub").html())));
            $("#final").html(formatter.format(parseInt($("#final").html())));
            for(var i = 0 ; i < len ; i++){
                $("#p"+i).html(formatter.format(parseInt($("#p"+i).html())));  
                $("#p2"+i).html(formatter.format(parseInt($("#p2"+i).html())));
               
               
            }
            $("#a").on('click',function(){
                $("#b").show();
                $('#d').removeAttr("disabled");
                $('#n').removeAttr("disabled");
                $('#c').removeAttr("disabled");
            });

            $("#b").on('click',function(){
                $(this).hide();
                $('#d').prop("disabled", true);
                $('#n').prop("disabled", true);
                $('#c').prop("disabled", true);
            });

            $("#de").on('click',function(){
                $('#d').prop("disabled", true);
                $('#n').prop("disabled", true);
                $('#c').prop("disabled", true);

                $('#d').val("<?php echo $adddress?>");
                $('#n').val("<?php echo $fullName?>");
                $('#c').val("<?php echo $contact?>");
            });
            
            $(".checkout").submit(function(e) {
            e.preventDefault(); // avoid to execute the actual submit of the form.

            var form = $(this);
            var url = form.attr('action');

            $.ajax({
                type: "POST",
                url: url,
                data: form.serialize(), // serializes the form's elements.
                success: function(data)
                {
                    Swal.fire({ 
                       icon: 'success',  
                        title:'Online Shop',
                        text: 'Successfull Place Order',  
                        showConfirmButton: false,  
                        timer: 2000
                    }).then(()=>{
                        window.location.href="transaction.php";
                    });
                }
                });
            });
        })
    </script>
</body>
</html>