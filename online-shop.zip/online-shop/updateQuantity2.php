<?php
	session_start();
	$products = simplexml_load_file('cart.xml');
    $newVal=0;
	foreach($products->cart as $product){
            if($product->prod_id == $_POST['prod_xid'] && $product->user_id == $_POST['user_id']){
				$product->quantity=intval($product->quantity)-intval($_POST['update_quantity']);
                $newVal = $product->quantity;
				break;
			}
		}
	file_put_contents('cart.xml', $products->asXML());
    echo strval($newVal);
?>