<!DOCTYPE html>
<html lang="en">
<head>
   <style>
        .d{
            height:100vh;
            position: relative;
            text-align: center;
        }
        .centered {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        }
   </style>
</head>
<body>
<div class="d container-fluid d-flex justify-content-center align-items-center bg-body">
    <img src="BG.png" style="width:52%;"  alt="">
    
</div>
   
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="font-monospace modal-title" id="exampleModalLabel">Login </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" id="login-form" >
            <div class="mb-3">
                <label for="username" class="mb-1 font-monospace">Email or Username: </label>
                <input type="text" name="username" autocomplete="off"  placeholder="Enter email or Username: "class="font-monospace form-control" id="username" >
            </div>
            <div class="mb-3">
                <label for="password" class="mb-1 font-monospace">Password: </label>
                <input type="password" name="password" placeholder="Enter password:" class="font-monospace form-control" id="password">
            </div>
            <div class="d-grid mt-4">
                <button class="text-white fw-bold font-monospace btn btn-info font-monospace" name="login" id="login" type="submit">LOGIN</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="font-monospace modal-title" id="exampleModalLabel">Sign Up </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" id="register-form" >
            <div data-tip="This is the text of the tooltip2" class="mb-2">
                <input type="text" name="fullname" placeholder="Fullname: " autocomplete="off" class="font-monospace form-control" id="fullname">
            </div>
            <div class="mb-2">
                <input type="text" maxlength="8" name="username" placeholder="Username: " autocomplete="off" class="font-monospace username form-control" id="username2" >
            </div>
            <div class="mb-2">
                <input type="password"  name="password" placeholder="Password: " autocomplete="off" class="font-monospace form-control" id="sassword" >
            </div>
            <div class="mb-2">
                <input type="text" name="email" placeholder="Email Address: " autocomplete="off" class="font-monospace form-control" id="email">
            </div>
            <div class="mb-2">
                <input type="text" name="contact" placeholder="Contact Number: " autocomplete="off" class="font-monospace form-control" id="contact" >
            </div>
            <div class="mb-2">
                <input type="text" name="address" placeholder="Delivery Address: " autocomplete="off" class="font-monospace form-control" id="address" >
            </div>
            <div class="row">
                <div class="col-6">
                    <input type="text" name="captcha" placeholder="Captcha " autocomplete="off" class="font-monospace form-control" id="cap-orig" >
                </div>
                <div class="col-4">
                    <input style="letter-spacing:10px;" type="text" id="pattern-captcha" disabled class='font-monospace fw-bold form-control'>
                </div>
                <div class="col-2">
                    <button type="button" class='btn cap'>
                    <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                
            </div>
            <div class="d-grid mt-3">
                <button class="text-white fw-bold btn btn-info font-monospace" name="signup" id="signup" type="submit">SIGN UP</button>
            </div>
            
        </form>
      </div>
    </div>
  </div>
</div>
</body>
<script>
    $(document).ready(function(){
        let captcha ="";
        let  holderCaptcha ="!@#$%^&*ABCDEFGHIJKLMNOPQRTSYUVWXYZ1234567890";
        for(let i = 0 ; i < 4 ; i++) {
            captcha += holderCaptcha.charAt(Math.floor(Math.random()*holderCaptcha.length));
        }
        $("#pattern-captcha").val(captcha);
        $(".cap").click(function(){
            captcha="";
            for(var i = 0 ; i < 4; i++) {
                captcha += holderCaptcha.charAt(Math.floor(Math.random()*holderCaptcha.length));
                $("pattern-captcha").val("");
                $("#pattern-captcha").val(captcha);
            }
        });

        $("#register-form").submit(function(e) {
            e.preventDefault(); // avoid to execute the actual submit of the form.
            
            if($("#cap-orig").val() != $("#pattern-captcha").val()){
                if(!alert('Captcha Verifcation Does Not Match Please Try Again..!')){
                    captcha="";
                    for(var i = 0 ; i < 4; i++) {
                        captcha += holderCaptcha.charAt(Math.floor(Math.random()*holderCaptcha.length));
                        $("#cap-orig").val("");
                        $("pattern-captcha").val("");
                        $("#pattern-captcha").val(captcha);
                    }
                }   
            }else{
                $.ajax({
                    type: "POST",
                    url: "addAccount.php",
                    data: $("#register-form").serialize(), // serializes the form's elements.
                    success: function(data)
                    {
                        Swal.fire({ 
                            icon: 'success',  
                            title: 'Congratulations, your account has been successfully created.',  
                            showConfirmButton: false,  
                            timer: 2000
                        }).then(()=>{
                            window.location.reload();
                        })		
                    }
                });
            }
        });

        $("#login-form").submit(function(e) {
            e.preventDefault(); // avoid to execute the actual submit of the form.
                $.ajax({
                    type: "POST",
                    url: "loginAccount.php",
                    data: $("#login-form").serialize(), // serializes the form's elements.
                    success: function(data)
                    {

                        switch(data){
                            case "username_not_found":
                                Swal.fire({ 
                                    icon: 'error',  
                                    title: 'Online Shop',
                                    text: 'The email or password you entered did not match our records. Please double-check and try again..!',  
                                    showConfirmButton: false,  
                                    timer: 3000
                                })
                                break;
                            case "login":
                                Swal.fire({ 
                                    icon: 'success',  
                                    title:'Online Shop',
                                    text: 'Login Successfully.',  
                                    showConfirmButton: false,  
                                    timer: 2000
                                }).then(()=>{
                                    location.href="home.php";
                                })		
                        }
                    }
                });
            
        });

        $('.username').on('keypress', function (event) {
            var regex = new RegExp("^[a-zA-Z0-9]+$");
            var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(key)) {
                $('username').css('border', 'solid 1px red');
            event.preventDefault();
            return false;
            }
        });
    });
</script>
</html>