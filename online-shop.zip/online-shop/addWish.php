<?php
	session_start();
	$xml = new DOMDocument();
	$xml->formatOutput = true;
	$xml->preserveWhiteSpace = false;
	$xml->load("wish.xml");
	$sxml = simplexml_load_file("wish.xml");
	$found=false;
    $len_cart = $xml->getElementsByTagName("wishs")[0]->getElementsByTagName('wish')->length;
	for($i = 0 ; $i < $len_cart;  $i++){
		if($sxml->wish[$i]->prod_id == $_POST['prod_xid'] && $sxml->wish[$i]->user_id == $_SESSION['user_id']){
			$found=true;
			break;
		}
	}
	if($found){
		echo "found";
	} else{
		$prod_id=$_POST['prod_xid'];
		$path = $_POST['prod_path'];
		$user_id = $_POST['user_id'];
		$quantity = $_POST['cart_quantity'];
		$unit_price =  $_POST['prod_price'];
		$available = $_POST['prod_available'];
		$prod_name = $_POST['prod_name'];
		$newProd = $xml -> createElement('wish');
		$newProd -> appendChild($xml -> createElement('user_id',$user_id));
		$newProd -> appendChild($xml -> createElement('prod_id',$prod_id));
		$newProd -> appendChild($xml -> createElement('path',$path));
		$newProd -> appendChild($xml -> createElement('prod_name',$prod_name));
		$newProd -> appendChild($xml -> createElement('unit_price',$unit_price));
		$newProd -> appendChild($xml -> createElement('available',$available));
		$newProd -> appendChild($xml -> createElement('quantity',$quantity));
		$xml -> getElementsByTagName('wishs') -> item(0) -> appendChild($newProd);
		$test = $xml -> save('wish.xml');	
	
		echo "save";
	}
?>
	