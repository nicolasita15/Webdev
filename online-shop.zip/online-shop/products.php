<?php
      $page = "item";
      include('home-header.php'); 
      if(empty($_SESSION["username"])) header("Location: index.php");
      $username= $_SESSION['username']."</br>";
      $user_id= $_SESSION['user_id'];
      $xml = simplexml_load_file("admin/product.xml");
        $products = array(); 
        foreach ($xml->product as $product) { 
        $products[] = array(
                'prod_id'=>(string)$product->prod_id,
                'prod_name'=>(string)$product->prod_name,
                'prod_brand'=>(string)$product->prod_brand,
                'prod_category'=>(string)$product->prod_category,
                'prod_price'=>(string)$product->prod_price,
                'prod_quantity'=>(string)$product->prod_quantity,
                'prod_path'=>(string)$product->prod_path,
                'prod_des'=>(string)$product->prod_des,
            );
        }
        $totalProducts = count($products);
        for($i = 0 ; $i < $totalProducts ; $i++){
            if($xml->product[$i]->prod_category ==  $_GET['category'] ){
                $mens[] = array(
                    'prod_id'=>(string)$xml->product[$i]->prod_id,
                    'prod_name'=>(string)$xml->product[$i]->prod_name,
                    'prod_brand'=>(string)$xml->product[$i]->prod_brand,
                    'prod_category'=>(string)$xml->product[$i]->prod_category,
                    'prod_price'=>(string)$xml->product[$i]->prod_price,
                    'prod_quantity'=>(string)$xml->product[$i]->prod_quantity,
                    'prod_path'=>(string)$xml->product[$i]->prod_path,
                    'prod_des'=>(string)$xml->product[$i]->prod_des,
                );
            }
        }
        $totalProducts = count($mens);
        $perPage = 6;
        $page = isset($_GET['page']) && ($page = intval($_GET['page'])) > 0 ?  $page : 1;
        $start = ($page - 1) * $perPage;
        $end = $start + $perPage;
        $menss = array();
        for ($a=$start; $a<$end; ++$a) { 
            if (isset($mens[$a])) { 
               $menss[] = $mens[$a];                 
            }
        }
        $pages = ceil($totalProducts / $perPage);  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
    <div class="container-fluid asd  p-5 d-flex flex-column align-items-center justify-content-center">
    <div class="product-container">
            <?php
                $countMen=0;
                foreach($menss as $men){
                    echo " <a style='text-decoration:none;color:black;'href='viewProduct.php?prod_id=".$men['prod_id']."'>
                        <div class='product' title='".$men['prod_name']."'>
                           
                            <span class='prod-name'>".$men['prod_name']."</span>
                            <div class='image-container'>
                                <img class='i' src='".$men['prod_path']."'>
                            </div>
                            <div class='info-container'>
                                <span>Price: </span>
                                <p id='".$countMen."' class='price' >".$men['prod_price']."</p>
                            </div>
                            <div class='info-container'>
                                <span>Quantity: </span>
                                <p class='price' >".$men['prod_quantity']."</p>
                            </div>
                                <div class='button-container mt-3 mb-2'>
                                    <form class='addCart' action='addCart.php'>
                                        <input type='hidden' name='prod_xid' value='".$men['prod_id']."'>
                                        <input type='hidden' name='user_id' value='".$user_id."'>
                                        <input type='hidden' name='cart_quantity' value='1'>
                                        <input type='hidden' name='prod_available' value='".$men['prod_quantity']."'>
                                        <input type='hidden' name='prod_price' value='".$men['prod_price']."'>
                                        <input type='hidden' name='prod_path' value='".$men['prod_path']."'>
                                        <input type='hidden' name='prod_name' value='".$men['prod_name']."'>
                                        <button class='btn-addcart' type='submit' title='Add to Cart' name='add-cart'>
                                          <i class='fas fa-cart-plus'></i>
                                        </button>
                                    </form>
                                    <form class='addWish' action='addWish.php'>
                                        <input type='hidden' name='prod_xid' value='".$men['prod_id']."'>
                                        <input type='hidden' name='user_id' value='".$user_id."'>
                                        <input type='hidden' name='cart_quantity' value='1'>
                                        <input type='hidden' name='prod_available' value='".$men['prod_quantity']."'>
                                        <input type='hidden' name='prod_price' value='".$men['prod_price']."'>
                                        <input type='hidden' name='prod_path' value='".$men['prod_path']."'>
                                        <input type='hidden' name='prod_name' value='".$men['prod_name']."'>
                                        <button class='btn-addwish' type='submit' title='Add to Wish List' name='add-wish'>
                                            <i class='fas fa-heart'></i>
                                        </button>
                                    </form>
                                </div>
                                
                        </div>
                        </a>
                    ";
                    $countMen++;
                }
            ?>
        </div>
        <div class="pagination" style="display:flex;width:100vw;justify-content:center;">
        <?php 
            for ($a=1; $a<=$pages; ++$a) {
                echo "<form method='POST' action='products.php?category=".$_GET['category']."&page=".$a."'>";
                    echo "<input type='hidden' name='category' value='".$_GET['category']."'>";
                    echo "<button style='font-size:18px;' id='x' class='btn btn-danger mx-2 fw-bold font-monospace' type='submit'>".$a."</button>";
                echo "</form>";
            }	
        ?>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            var x = <?php echo $totalProducts?>;
            
         
            var formatter = new Intl.NumberFormat('en-PH', {
                style: 'currency',
                currency: 'PHP',
            });
            for(var i = 0 ; i < x ; i++){
                $("#"+i).html(formatter.format(parseInt($("#"+i).html())));
                
            }
            $(".addCart").submit(function(e) {
                e.preventDefault(); // avoid to execute the actual submit of the form.

                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    complete: function(data)
                    {
                        if(data.responseText === "save\t"){
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Item has been added to your shopping cart',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        } else if(data.responseText === "found\t"){
                        Swal.fire({ 
                            icon:'info',
                            title:'Online Shop',
                            text: 'This product is already in your shopping .',  
                            showConfirmButton: false,  
                            timer: 2000
                        })
                    }
                }
                });
            });

            $(".addWish").submit(function(e) {

                e.preventDefault(); // avoid to execute the actual submit of the form.

                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    complete: function(data)
                    {
                        if(data.responseText === "save\t"){
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Item has been added to your shopping wishlist',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        } else if(data.responseText === "found\t"){
                            Swal.fire({ 
                                icon:'info',
                                title:'Online Shop',
                                text: 'This product is already in your shopping wishlist.',  
                                showConfirmButton: false,  
                                timer: 2000
                            })
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>