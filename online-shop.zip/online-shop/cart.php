<?php
    $page = "cart";
    include('home-header.php'); 
    $sxml = simplexml_load_file("cart.xml");
    $xml = new DOMDocument( "1.0");
    $xml->load("cart.xml");

    $len_cart = $xml->getElementsByTagName("carts")[0]->getElementsByTagName('cart')->length;
   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./products.css">
</head>
<body>
    <div class="action-container" >
        <div class="btn-container">
            <button id='mul-del' class='col-1 me-2 btn btn-danger'>DELETE</button>
            <button id='mul-check' class='col-1  btn btn-outline-danger me-5'>CHECKOUT</button>
        </div>

    </div>
    <div style='height:auto;' class=" container-fluid pb-5 d-flex flex-column align-items-center  ">
  
        <div class="product-container">
            <?php
             for($i = 0 ; $i < $len_cart;  $i++){
                if($sxml->cart[$i]->user_id == $_SESSION['user_id']){
                echo "
                    <div class='product'>
                        <form method='post' class='mb-2 d-flex align-items-center mul-del'>
                            <input type='checkbox' name='prodss[]' id='".$sxml->cart[$i]->prod_id."' class='cbox' value='".$sxml->cart[$i]->prod_id."'>
                            <label for='".$sxml->cart[$i]->prod_id."' class='fw-bold font-monospace ms-2 text-truncate d-inline-block' style='width:220px;'>".$sxml->cart[$i]->prod_name."</label>
                        </form>
                       
                        <div class='image-container'>
                            <img class='i' src='".$sxml->cart[$i]->path."'>
                        </div>
                        <div class='info-container'>
                            <span>Unit Price:</span>
                            <p id='p".$i."' class='price'>".$sxml->cart[$i]->unit_price."</p>
                        </div>
                        <div class='info-container'>
                            <span>Stocks:</span>
                            <p class='price'>".$sxml->cart[$i]->available."</p>
                        </div>  
                        <div class='info-container'>
                            <span>Order:</span>
                            <p id='upd'".$i."' class='price'>".$sxml->cart[$i]->quantity."</p>
                            
                        </div>  
                        <div class='info-container'>
                            <span>Total:</span>
                            <p id='p2".$i."' class='price'>".intval($sxml->cart[$i]->quantity)*intval($sxml->cart[$i]->unit_price)."</p>
                        </div> 
                        <div class='d-flex'>
                            <form class='addWish' method='post' action='cartToWish.php'>
                            <input type='hidden' name='prod_xid' value='".$sxml->cart[$i]->prod_id."'>
                            <input type='hidden' name='user_id' value='".$sxml->cart[$i]->user_id."'>
                            <input type='hidden' name='cart_quantity' value='".$sxml->cart[$i]->quantity."'>
                            <input type='hidden' name='prod_available' value='".$sxml->cart[$i]->available."'>
                            <input type='hidden' name='prod_price' value='".$sxml->cart[$i]->unit_price."'>
                            <input type='hidden' name='prod_path' value='".$sxml->cart[$i]->path."'>
                            <input type='hidden' name='prod_name' value='".$sxml->cart[$i]->prod_name."'>
                            <button class='btn-addwish btn btn-danger' type='submit' title='Add to Wish List' name='add-wish'>
                                <i class='fas fa-heart'></i>
                            </button>
                            </form> 
                            <form class='upd-q' action='updateQuantity.php'>
                                <input type='hidden' name='prod_xid' value='".$sxml->cart[$i]->prod_id."'>
                                <input type='hidden' name='user_id' value='".$sxml->cart[$i]->user_id."'>
                                <input type='hidden' name='update_quantity' value='1'>
                                <button type='submit' class='ms-2 btn btn-outline-info'>
                                    <i class='fas fa-plus'></i>
                                </button> 
                            </form>  
                            <form class='upd-q' action='updateQuantity2.php'>
                                <input type='hidden' name='prod_xid' value='".$sxml->cart[$i]->prod_id."'>
                                <input type='hidden' name='user_id' value='".$sxml->cart[$i]->user_id."'>
                                <input type='hidden' name='update_quantity' value='1'>
                                <button type='submit' class='ms-2 btn btn-outline-info'>
                                    <i class='fas fa-minus'></i>
                                </button> 
                            </form>  
                        </div>  
                    </div>
                    ";
                }
                else{
                    
                }
            }
            ?>
        </div> 
    </div>
    <script>
        $(document).ready(function(){
            let counter=0;
            var len = <?php echo $len_cart;?>;
           
            var formatter = new Intl.NumberFormat('en-PH', {
                style: 'currency',
                currency: 'PHP',
            });
            $("#final").html(formatter.format(parseInt($("#final").html())));
            for(var i = 0 ; i < len ; i++){
                $("#p"+i).html(formatter.format(parseInt($("#p"+i).html())));  
                $("#p2"+i).html(formatter.format(parseInt($("#p2"+i).html())));
            }
            $("#mul-check").hover(
                function(){
                    $("#mul-del").removeClass('btn-danger');
                    $("#mul-del").addClass('btn-outline-danger');
                },
                function(){
                    $("#mul-del").removeClass('btn-outline-danger');
                    $("#mul-del").addClass('btn-danger');
                }
            );
            $(".addWish").submit(function(e) {
                e.preventDefault(); // avoid to execute the actual submit of the form.

                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    complete: function(data)
                    {
                        if(data.responseText === "save\t"){
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Item has been added to your shopping wishlist',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        } else if(data.responseText === "found\t"){
                            Swal.fire({ 
                                icon:'info',
                                title:'Online Shop',
                                text: 'This product is already in your shopping wishlist.',  
                                showConfirmButton: false,  
                                timer: 2000
                            })
                        }
                    }
                });
            });
            $(".upd-q").submit(function(e){
                e.preventDefault();
                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    complete: function ajaxLoop(data)
                    {
                        window.location.reload();
                    }
                });

            })

            $(".upd-q2").submit(function(e){
                e.preventDefault();
                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    complete: function ajaxLoop(data)
                    {
                        window.location.reload();
                    }
                });

            })
            $("#mul-del").on('click',function(event){
                var x = confirm("Are you sure want to remove all this checked products?")
                var prods = new Array();
                if(x){
                    $( "input[name='prodss[]']:checked" ).each( function() {
                            prods.push( $( this ).val() );
                    } );
                    if(prods.length == 0){
                        Swal.fire({ 
                            icon: 'error',  
                            title:'Online Shop',
                            text: 'No items selected.',  
                            showConfirmButton: false,  
                            timer: 2000
                            })
                    } else {
                        $.ajax({
                        type:'POST',
                        url: 'delMultiple.php',
                        data:'cb='+prods,
                        
                        complete:function(data){
                       
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Products successfully removed to your cat.',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        }

                    })
                    }
                    

                }
            });

            $("#mul-check").on('click',function(event){
                var prods = new Array();
                    $( "input[name='prodss[]']:checked" ).each( function() {
                            prods.push( $( this ).val() );
                    } );
                    if(prods.length == 0){
                        Swal.fire({ 
                            icon: 'error',  
                            title:'Online Shop',
                            text: 'No items selected.',  
                            showConfirmButton: false,  
                            timer: 2000
                            })
                    } else {
                        window.location.href='checkout.php?id='+prods;
                    }
            });
          
        });
    </script>
</body>

</html>
