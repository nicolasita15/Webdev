<?php
    session_start();
    $x = $_POST['cb'];
    $carts = simplexml_load_file('cart.xml');
	$index = 0;
    $new_id = str_replace(array( '\'', '"',
    ',' , ';', '<', '>' ), ' ',$x);
    $new="";
    $new_id = preg_replace('/\s+/', '', $new_id);
    for($i = 0 ; $i < strlen($new_id) ; $i++){
        foreach($carts->cart as $per_item){
            if($per_item->prod_id == $new_id[$i] && $per_item->user_id == $_SESSION['user_id']){
                unset($carts->cart[$index]);
                $index=0;
                break;
            }else{
                $index++;
            }
        }
        file_put_contents('cart.xml', $carts->asXML());
        continue;
    }
    echo $new;

?>