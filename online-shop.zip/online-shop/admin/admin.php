<?php
    session_start();
    if(empty($_SESSION["username"])) header("Location: index.php");  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   <style>
       html,body{
           margin:0;
           padding:0;
           box-sizing: border-box;
           font-family: Century Gothic;
       }
       img{
           width:50px
           
       }

   </style>
</head>
<?php
    $xml = simplexml_load_file("product.xml");
    $products = array(); 
    foreach ($xml->product as $product) { 
    $products[] = array(
        'prod_id'=>(string)$product->prod_id,
        'prod_name'=>(string)$product->prod_name,
        'prod_brand'=>(string)$product->prod_brand,
        'prod_category'=>(string)$product->prod_category,
        'prod_price'=>(string)$product->prod_price,
        'prod_quantity'=>(string)$product->prod_quantity,
        'prod_path'=>(string)$product->prod_path,
        'prod_description'=>(string)$product->prod_description,
        );
    }
?>
<body>
    <div class="container-fluid py-5 bg-white" style="height:100vh;">
       <div class="container bg-light">
        <div class="row p-4 d-flex justify-content-end">
            <button type="button" class="col-1 btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <i class="fas fa-plus-circle"></i>ADD
            </button>
        </div>
       <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">PRODUCT</th>
                    <th scope="col">NAME</th>
                    <th scope="col">BRAND</th>
                    <th scope="col">CATEGORY</th>
                    <th scope="col">QUANTITY</th>
                    <th scope="col">PRICE</th>
                    <th scope="col">ACTION</th>
                </tr>
            </thead>
            <tbody>
                
                <?php
                foreach($products as $product){
                    echo "
                        <tr>
                            <td class='d-none'>".$product['prod_id']."</td>
                            <td class='d-none'>".$product['prod_description']."</td>
                            <td class='d-none'>".strval($product['prod_path'])."</td>
                            <td><img src='".$product['prod_path']."'></td>
                            <td>".$product['prod_name']."</td>
                            <td>".$product['prod_brand']."</td>
                            <td>".$product['prod_category']."</td>
                            <td>".$product['prod_quantity']."</td>
                            <td>".$product['prod_price']."</td>
                            <td >
                                <form class='del-form' method='post' action='deleteProduct.php'>
                                    <input type='hidden' name='prod_id'  value='".$product['prod_id']."'>
                                    <button type='submit' class='me-2 btn btn-danger'>
                                        <i class='fas fa-trash'></i>
                                    </button>
                                    <button type='button' class='edit-btn btn btn-success'>
                                        <i class='fas fa-pen-alt'></i>
                                    </button>   
                                </form>
                                
                               
                            </td>
                        </tr>
                    ";
                }
                ?>
            </tbody>
        </table>
       </div>
    </div>
    <div class="modal" id="exampleModal" tabindex="-1"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body row">
                    <div class="col-7 bg-light d-flex align-items-center">
                        <div id="image-preview">
                            <img style="width:100%;" src="" id="img" alt="">
                        </div>
                    </div>
                    <div class="col-5">
                        <form method="POST" onsubmit="return addProduct(this)" >
                        <div class="mb-2">
                            <input type="text" placeholder="Product Name: " autocomplete="off" class="form-control" name="prod_name">
                        </div>
                        <div class="mb-2">
                            <input type="text" placeholder="Brand: " autocomplete="off" class="form-control" name="prod_brand" >
                        </div>
                        <div class="mb-2">
                            <input type="text" placeholder="Category: " autocomplete="off" class="form-control" name="prod_category"  >
                        </div>
                        <div class="mb-2">
                            <input type="text" placeholder="Image: " autocomplete="off" class="form-control" name="prod_image" id="prod_path" >
                        </div>
                        <div class="mb-2">
                            <input type="text" placeholder="Price: " autocomplete="off" class="form-control" name="prod_price"  >
                        </div>
                        <div class="mb-2">
                            <input type="text" placeholder="Quantity: " autocomplete="off" class="form-control" name="prod_quantity" >
                        </div>
                        <div class="mb-2">
                            <textarea class="form-control" autocomplete="off"  placeholder="Desription" name="prod_des" aria-label="With textarea"></textarea>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-primary" name="add" id="add" type="submit">ADD</button>
                        </div>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- UPDATE MODAL -->
    <div class="modal fade" id="edit-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body row">
                    <div class="col-7 bg-light d-flex align-items-center">
                        <div id="image-preview">
                            <img style="width:100%;" src="" id="img2" alt="">
                        </div>
                    </div>
                    <div class="col-5">
                        <form method="POST" action="updateProduct.php" >
                            <div class="mb-2">
                                <input type="hidden" name="update_id" id="update_id">
                                <input type="text" placeholder="Product Name: " autocomplete="off" class="form-control" id="update_name" name="update_name">
                            </div>
                            <div class="mb-2">
                                <input type="text" placeholder="Brand: " autocomplete="off" class="form-control" id="update_brand" name="update_brand" >
                            </div>
                            <div class="mb-2">
                                <input type="text" placeholder="Category: " autocomplete="off" class="form-control" id="update_category" name="update_category"  >
                            </div>
                            <div class="mb-2">
                                <input type="text" placeholder="Image: " autocomplete="off" class="form-control update_image" name="update_image" id="prod_path2" >
                            </div>
                            <div class="mb-2">
                                <input type="text" placeholder="Price: " autocomplete="off" class="form-control" id="update_price" name="update_price"  >
                            </div>
                            <div class="mb-2">
                                <input type="text" placeholder="Quantity: " autocomplete="off" class="form-control" id="update_quantity" name="update_quantity" >
                            </div>
                            <div class="mb-2">
                                <textarea class="form-control" autocomplete="off"  placeholder="Desription" name="update_des" id="update_des" aria-label="With textarea"></textarea>
                            </div>
                        
                            <button class="btn btn-success" name="update" id="update" type="submit">UPDATE</button>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<script>
    $(document).ready(function(){
        $('.edit-btn').on('click',function() {
            $('#edit-modal').modal('show');
            $tr= $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
            }).get();
            $('#update_id').val(data[0]);
            $('#update_name').val(data[4]);
            $('#update_brand').val(data[5]);
            $('#update_category').val(data[6]);
            $('#update_price').val(data[8]);
            $('#update_quantity').val(data[7]);
            $('.update_image').val(data[2]);
            $('#update_des').val(data[1]);
        });
        $(function() {
            $(".btn-danger").click(function(event){
                var x = confirm("Are you sure want to delete this product?")
                if (x==true){
                    $('.del-form').submit();
                }else{
                    event.preventDefault();
                }
            });
        });
        $('#prod_path').on('input',function(e){
            var x = $('#prod_path').val();
            $('#img').attr('src',x);
        });
        $('#prod_path2').on('input',function(e){
            var x = $('#prod_path2').val();
            $('#img2').attr('src',x);
        });
    });
    function addProduct(form){
        prod_name = form.prod_name.value;
        prod_brand = form.prod_brand.value;
        prod_category = form.prod_category.value;
        prod_price = form.prod_price.value;
        prod_quantity = form.prod_quantity.value;
        prod_path = form.prod_image.value;
        prod_des = form.prod_des.value;
        xml = new XMLHttpRequest();
	    xml.onreadystatechange = function() {
		    if(xml.readyState==4 && xml.status==200) {
                window.location.reload();
		    }
	    };
		xml.open("GET", "addProduct.php?prod_des="+prod_des+"&prod_name="+prod_name+"&prod_brand="+prod_brand+"&prod_category="+prod_category+"&prod_price="+prod_price+"&prod_path="+prod_path+"&prod_quantity="+prod_quantity, true);
		xml.send();
		return false;
   }


   
</script>
</body>
</html>