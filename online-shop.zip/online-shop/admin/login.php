<?php
    session_start();
    if(isset($_SESSION["username"])) header("location: home.php");
    if($_POST['username']){
        if($_POST['username'] == "admin" && $_POST['password'] == "admin"){
            $_SESSION['username'] = $_POST['username'];
            echo json_encode(array("statusCode"=>200));
		}
		else{
			echo json_encode(array("statusCode"=>404));
		}
    }
?>