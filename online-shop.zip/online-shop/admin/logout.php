<?php
session_start(); //sinimulan
session_destroy(); //winakasan
header("Location: index.php"); //nag move-on
?>