<?php
    $id = $_POST['prod_id'];
 
	$products = simplexml_load_file('product.xml');
    
	//we're are going to create iterator to assign to each user
	$index = 0;
	$i = 0;
  
	foreach($products->product as $product){
		if($product->prod_id == $id){
			$index = $i;
			break;
		}
		$i++;
	}
    
	unset($products->product[$index]);
	file_put_contents('product.xml', $products->asXML());
	header('Location:admin.php');
 
?>