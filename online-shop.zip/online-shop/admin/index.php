<?php
    session_start();
    if(isset($_SESSION["username"])) header("location: admin.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,body{
            margin:0;

        }
    </style>
</head>
<body>
    <div style="height:100vh;" class="py-5 container-fluid bg-white p-3 justify-content-start align-items-center d-flex flex-column">
        <h1 class="mt-5 mb-3">Login Form</h1>
        <form style="width:30vw;" method="POST" class="shadow-lg p-4 mb-5 bg-white rounded">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" autocomplete="off" class="form-control" id="username" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password">
            </div>
            <div class="d-grid mt-5">
                <button class="btn btn-primary" name="login" id="login" type="button">LOGIN</button>
            </div>
        </form>
    </div>
</body>
<script>
    $(document).ready(function(){
        $('#login').on('click', function() {
		var username = $('#username').val();
		var password = $('#password').val();
		if(username!="" && password!="" ){
			$.ajax({
				url: "login.php",
				type: "POST",
				data: {
					username: username,
					password: password						
				},
				cache: false,
				success: function(res){
					var res = JSON.parse(res);
					if(res.statusCode==200){
                        Swal.fire({ 
                            icon: 'success',  
                            title: 'Successfull Login',  
                            showConfirmButton: false,  
                            timer: 2000
                        }).then(()=>{
                            location.href="admin.php";
                        })					
					}
					else if(res.statusCode==404){
						Swal.fire({
                            title:"Username or Password is incorrect please try again..!",
                            icon:"error",
                            timer: 2000,
                            showConfirmButton:false
                        });
            
					}
					
				}
			});
		}
		else{
			Swal.fire({
                text:"Please fill all the field!",
                icon:"error",
                timer: 2000,
                showConfirmButton:false
            });
            
		}
	});
    });
</script>

</html>