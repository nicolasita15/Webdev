<?php
	session_start();
	if(isset($_POST['update'])){
		$products = simplexml_load_file('product.xml');
		foreach($products->product as $product){
            
			if($product->prod_id == $_POST['update_id']){
				$product->prod_name = $_POST['update_name'];
				$product->prod_brand = $_POST['update_brand'];
				$product->prod_category = $_POST['update_category'];
                $product->prod_path = $_POST['update_image'];
				$product->prod_price = $_POST['update_price'];
                $product->prod_quantity = $_POST['update_quantity'];
				$product->prod_description = $_POST['update_des'];
				break;
			}
		}
 
		file_put_contents('product.xml', $products->asXML());
        header('location:admin.php');
		
	}
 
?>