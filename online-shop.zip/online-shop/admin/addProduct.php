<?php
	
	$xml = new DOMDocument();
	$xml->formatOutput = true;
	$xml->preserveWhiteSpace = false;
	$xml->load("product.xml");
	$newProduct =  $xml -> getElementsByTagName('product');
    
	$prod_name = $_GET["prod_name"];
	$prod_brand = $_GET["prod_brand"];
	$prod_category = $_GET["prod_category"];
	$prod_path = $_GET["prod_path"];
    $prod_price = $_GET["prod_price"];
	$prod_des = $_GET["prod_des"];
    $prod_quantity = $_GET["prod_quantity"];
    $prod_id = $newProduct->length;
	$newProduct = $xml -> createElement('product');
    $newProduct -> appendChild($xml -> createElement('prod_id',$prod_id++));
	$newProduct -> appendChild($xml -> createElement('prod_name',$prod_name));
	$newProduct -> appendChild($xml -> createElement('prod_brand',$prod_brand));
	$newProduct -> appendChild($xml -> createElement('prod_category',$prod_category));
	$newProduct -> appendChild($xml -> createElement('prod_path',$prod_path));
    $newProduct -> appendChild($xml -> createElement('prod_price',$prod_price));
	$newProduct -> appendChild($xml -> createElement('prod_quantity',$prod_quantity));
	$newProduct -> appendChild($xml -> createElement('prod_description',$prod_des));
	$xml -> getElementsByTagName('products') -> item(0) -> appendChild($newProduct);
	$test = $xml -> save('product.xml');
 
	header('Location:admin.php');
	
?>

