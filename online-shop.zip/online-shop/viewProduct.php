<?php
    $page = "item";
    include('home-header.php'); 
    if(empty($_SESSION["username"])) header("Location: index.php");
    $username= $_SESSION['username']."</br>";
    $user_id= $_SESSION['user_id'];

    $xml = simplexml_load_file("admin/product.xml");
    $products = array(); 
    foreach ($xml->product as $product) { 
        $products[] = array(
            'prod_id'=>(string)$product->prod_id,
            'prod_name'=>(string)$product->prod_name,
            'prod_brand'=>(string)$product->prod_brand,
            'prod_category'=>(string)$product->prod_category,
            'prod_price'=>(string)$product->prod_price,
            'prod_quantity'=>(string)$product->prod_quantity,
            'prod_path'=>(string)$product->prod_path,
            'prod_des'=>(string)$product->prod_description,
        );
    }
    $totalProducts = count($products);
    for($i = 0 ; $i < $totalProducts ; $i++){
        if($xml->product[$i]->prod_id ==  $_GET['prod_id'] ){
            $mens[] = array(
                'prod_id'=>(string)$xml->product[$i]->prod_id,
                'prod_name'=>(string)$xml->product[$i]->prod_name,
                'prod_brand'=>(string)$xml->product[$i]->prod_brand,
                'prod_category'=>(string)$xml->product[$i]->prod_category,
                'prod_price'=>(string)$xml->product[$i]->prod_price,
                'prod_quantity'=>(string)$xml->product[$i]->prod_quantity,
                'prod_path'=>(string)$xml->product[$i]->prod_path,
                'prod_des'=>(string)$xml->product[$i]->prod_description,
            );
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="viewProduct.css">
</head>
<body>
   <?php
        foreach($mens as  $prod){
            echo "
                <div class='product-view' title='".$prod['prod_name']."'>
                    <div class='product-container'>
                        <div class='image-container'>
                            <img class='img-path' src='".$prod['prod_path']."' alt=''>
                            
                        </div>
                        <div class='info-container'>
                            <p class='cat-name'>".$prod['prod_category']."'s Shoe </p>
                            <p class='name'>Name: ".$prod['prod_name']."</p>
                            <p class='price'>Brand: ".$prod['prod_brand']."</p>
                            <p class='price'>Price:<span class='price2'>".$prod['prod_price']."</span> </p>
                            <p class='price'>Available:<span>".$prod['prod_quantity']."</span> </p>
                            <div class='addq-container'>
                                Quantity:
                                <button class='add'>+</button>
                                <input type='hidden' value='".$prod['prod_quantity']."' class='available' disabled>
                                <input type='text' value='1' class='add-quantity' disabled>
                                <button class='minus'>-</button>
                            </div>
                            <div class='btn-container mt-5'>
                                <form class='addCart' action='addCart.php'>
                                    <input type='hidden' name='prod_xid' value='".$prod['prod_id']."'>
                                    <input type='hidden' name='user_id' value='".$user_id."'>
                                    <input type='hidden' name='cart_quantity' id='qty' value='1'>
                                    <input type='hidden' name='prod_available' value='".$prod['prod_quantity']."'>
                                    <input type='hidden' name='prod_price' value='".$prod['prod_price']."'>
                                    <input type='hidden' name='prod_path' value='".$prod['prod_path']."'>
                                    <input type='hidden' name='prod_name' value='".$prod['prod_name']."'>
                                    <button title='CART' type='submit' name='btn-add' id='a' class='btn btn-danger'>ADD TO CART
                                        <i class='far fa-cart-plus'></i>
                                    </button>
                                </form>
                                <form class='addWish' action='addWish.php'>
                                        <input type='hidden' name='prod_xid' value='".$prod['prod_id']."'>
                                        <input type='hidden' name='user_id' value='".$user_id."'>
                                        <input type='hidden' name='cart_quantity' id='qty-wish' value='1'>
                                        <input type='hidden' name='prod_available' value='".$prod['prod_quantity']."'>
                                        <input type='hidden' name='prod_price' value='".$prod['prod_price']."'>
                                        <input type='hidden' name='prod_path' value='".$prod['prod_path']."'>
                                        <input type='hidden' name='prod_name' value='".$prod['prod_name']."'>
                                        <button title='WISH' type='submit' id='wish' class='ms-2 btn btn-outline-danger'>ADD TO WISH
                                            <i class='far fa-cart-plus'></i>
                                        </button>
                                </form>
                            </div>
                        </div>
                        
                    </div>
                    <div class='prod-des-container'>
                        <p class='prod-name'>".$prod['prod_des']."</p>
                    </div>
                    
                </div> 
                
            ";
        }
   ?>
   <script>
        $(document).ready(function() {

            var formatter = new Intl.NumberFormat('en-PH', {
            style: 'currency',
            currency: 'PHP',
            });
            $(".price2").html(formatter.format(parseInt($(".price2").html())))
          
            $("#wish").hover(
                function(){
                    $("#a").removeClass('btn-danger');
                    $("#a").addClass('btn-outline-danger');
                },
                function(){
                    $("#a").removeClass('btn-outline-danger');
                    $("#a").addClass('btn-danger');
                }
            );
            $(".add").on("click", function () {
                let val = $(".add-quantity").val();
                let avl = $(".available").val();
                if(parseInt(val) != parseInt(avl)){
                    val=parseInt(val)+1
                    $(".add-quantity").val(val);
                    $("#qty").val(val);
                    $("#qty-wish").val(val);

                }
                
            });
            $(".minus").on("click", function () {
                let val = $(".add-quantity").val();
                if(parseInt(val) != 1){
                    val=parseInt(val)-1
                    $(".add-quantity").val(val);
                    $("#qty").val(val);
                    $("#qty-wish").val(val)
                }
                
            });
            
            $(".addCart").submit(function(e) {
            e.preventDefault(); // avoid to execute the actual submit of the form.

            var form = $(this);
            var url = form.attr('action');

            $.ajax({
                type: "POST",
                url: url,
                data: form.serialize(), // serializes the form's elements.
                complete: function(data)
                {
                    if(data.responseText === "save\t"){
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Item has been added to your shopping cart',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        } else if(data.responseText === "found\t"){
                            Swal.fire({ 
                                icon:'info',
                                title:'Online Shop',
                                text: 'This product is already in your shopping .',  
                                showConfirmButton: false,  
                                timer: 2000
                            })
                        }
                }
                });
            });

            $(".addWish").submit(function(e) {

                e.preventDefault(); // avoid to execute the actual submit of the form.

                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(), // serializes the form's elements.
                    success: function(data)
                    {
                        if(data.responseText === "save\t"){
                            Swal.fire({ 
                            icon: 'success',  
                            title:'Online Shop',
                            text: 'Item has been added to your shopping wishlist',  
                            showConfirmButton: false,  
                            timer: 2000
                            }).then(()=>{
                                window.location.reload();
                            });
                        } else if(data.responseText === "found\t"){
                            Swal.fire({ 
                                icon:'info',
                                title:'Online Shop',
                                text: 'This product is already in your shopping wishlist.',  
                                showConfirmButton: false,  
                                timer: 2000
                            })
                        }
                    }
                });
            });
        });
   </script>
</body>
</html>