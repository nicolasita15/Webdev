<?php
    session_start();
    $all_id = $_POST['new_id'];
    $all_qty = $_POST['all_qty'];
    $products = simplexml_load_file('admin/product.xml');
    $carts = simplexml_load_file('cart.xml');
    $prod = new DOMDocument( "1.0");
    $prod->load("admin/product.xml");
    $newQty=0;

   
    $len_product = $prod->getElementsByTagName("products")[0]->getElementsByTagName('product')->length;
    for($i = 0 ; $i < strlen($all_id) ; $i++){
        for($x = 0 ; $x < $len_product ; $x++){
                if($products->product[$x]->prod_id == $all_id[$i]){
                        $newQty = intval($products->product[$x]->prod_quantity)-intval($all_qty[$i]);
                        $products->product[$x]->prod_quantity = $newQty;
                        file_put_contents('admin/product.xml', $products->asXML());
                }
        }
    }
    $index = 0;
    for($i = 0 ; $i < strlen($all_id) ; $i++){
        foreach($carts->cart as $per_item){
            if($per_item->prod_id == $all_id[$i] && $per_item->user_id == $_SESSION['user_id']){
                unset($carts->cart[$index]);
                $index=0;
                break;
            }else{
                $index++;
            }
        }
        file_put_contents('cart.xml', $carts->asXML());
        continue;
    }
    
    
    for($m = 0 ; $m < strlen($all_id) ; $m++){
        $transaction = new DOMDocument();
        $transaction->formatOutput = true;
        $transaction->preserveWhiteSpace = false;
        $transaction->load("transaction.xml");	
        
        $prod_id=$all_id[$m];
        $qty=$all_qty[$m];
        $newProd = $transaction -> createElement('transaction');
        $newProd -> appendChild($transaction -> createElement('user_id',$_SESSION['user_id']));
        $newProd -> appendChild($transaction -> createElement('prod_id',$prod_id));
        $newProd -> appendChild($transaction -> createElement('quantity',$qty));

        $transaction -> getElementsByTagName('transactions') -> item(0) -> appendChild($newProd);
        $transaction -> save('transaction.xml');
        	
    }
    
  
    echo "save";
    
    
?>  