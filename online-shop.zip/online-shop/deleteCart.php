<?php
	session_start();
	$wishs = simplexml_load_file('wish.xml');
	$index = 0;
	foreach($wishs->wish as $per_item){
		if($per_item->prod_id == $_POST['prod_id'] && $per_item->user_id == $_SESSION['user_id']){
			unset($wishs->wish[$index]);
			break;
		}else{
			$index++;
		}
	}

	file_put_contents('wish.xml', $wishs->asXML()); 
?>