<?php
	session_start();
	$xml = new DOMDocument();
	$xml->formatOutput = true;
	$xml->preserveWhiteSpace = false;
	$xml->load("cart.xml");
	$sxml = simplexml_load_file("cart.xml");
	$found=false;
    $len_cart = $xml->getElementsByTagName("carts")[0]->getElementsByTagName('cart')->length;
	for($i = 0 ; $i < $len_cart;  $i++){
		if($sxml->cart[$i]->prod_id == $_POST['prod_id'] && $sxml->cart[$i]->user_id == $_SESSION['user_id']){
			$found=true;
			break;
		}
	}
	if($found){
		echo "found";
	} else{
		$prod_id=$_POST['prod_id'];
		$path = $_POST['prod_path'];
		$user_id = $_SESSION['user_id'];
		$quantity = $_POST['cart_quantity'];
		$unit_price =  $_POST['prod_price'];
		$available = $_POST['prod_available'];
		$prod_name = $_POST['prod_name'];
		$newProd = $xml -> createElement('cart');
		$newProd -> appendChild($xml -> createElement('user_id',$user_id));
		$newProd -> appendChild($xml -> createElement('prod_id',$prod_id));
		$newProd -> appendChild($xml -> createElement('path',$path));
		$newProd -> appendChild($xml -> createElement('prod_name',$prod_name));
		$newProd -> appendChild($xml -> createElement('unit_price',$unit_price));
		$newProd -> appendChild($xml -> createElement('available',$available));
		$newProd -> appendChild($xml -> createElement('quantity',$quantity));
		$xml -> getElementsByTagName('carts') -> item(0) -> appendChild($newProd);
		$test = $xml -> save('cart.xml');	

        $wishs = simplexml_load_file('wish.xml');
        $index = 0;
        foreach($wishs->wish as $per_item){
            if($per_item->prod_id == $_POST['prod_id'] && $per_item->user_id == $_SESSION['user_id']){
                unset($wishs->wish[$index]);
                break;
            }else{
                $index++;
            }
        }
    
        file_put_contents('wish.xml', $wishs->asXML()); 
    
		echo "save";
	}
?>
	