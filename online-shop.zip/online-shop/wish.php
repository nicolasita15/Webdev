<?php
$page = "wishlist";
    include('home-header.php'); 
    $sxml = simplexml_load_file("wish.xml");
    $xml = new DOMDocument( "1.0");
    $xml->load("wish.xml");
    $len_cart = $xml->getElementsByTagName("wishs")[0]->getElementsByTagName('wish')->length;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./products.css">
</head>
<body>
    <div style='height:auto;' class="container-fluid d-flex flex-column   align-items-center p-5 ">
        <div class="product-container">
            <?php
             for($i = 0 ; $i < $len_cart;  $i++){
                if($sxml->wish[$i]->user_id == $_SESSION['user_id']){
                echo "
                    <div class='product'>
                        <span class='fw-bold fw-monospace text-center p-0 m-0 text-truncate d-inline-block' style='width:200px;'>".$sxml->wish[$i]->prod_name."</span>
                        <div class='image-container'>
                            <img class='i' src='".$sxml->wish[$i]->path."'>
                        </div>
                           
                            <div class='info-container'>
                                <span>Price: </span>
                                <p id='p".$i."' class='price' >".$sxml->wish[$i]->unit_price."</p>
                            </div>
                            <div class='info-container'>
                                <span>Availalbe: </span>
                                <p  class='price' >".$sxml->wish[$i]->available."</p>
                            </div>
                            <div class='info-container'>
                                <span>Order: </span>
                                <p  class='price' >".$sxml->wish[$i]->quantity."</p>
                            </div>
                            <div class='button-container  mt-3 mb-2'>
                                <button class='btn btn-outline-danger bnt-add'>ADD TO CART
                                    <form method='post' id='add-cart'>
                                        <input type='hidden' name='prod_id' value='".$sxml->wish[$i]->prod_id."'>
                                        <input type='hidden' name='prod_path' value='".$sxml->wish[$i]->path."'>
                                        <input type='hidden' name='prod_name' value='".$sxml->wish[$i]->prod_name."'>
                                        <input type='hidden' name='prod_price' value='".$sxml->wish[$i]->unit_price."'>
                                        <input type='hidden' name='prod_available' value='".$sxml->wish[$i]->available."'>
                                        <input type='hidden' name='cart_quantity' value='".$sxml->wish[$i]->quantity."'>
                                   </form>
                                </button>
                                <button class='btn btn-danger btn-del'>DELETE
                                    <form method='post' id='del-cart'>
                                        <input type='hidden' name='prod_id' value='".$sxml->wish[$i]->prod_id."'>
                                    </form>
                                </button>
                            </div>
                           
                    </div>
                    ";
                }
                else{
                    
                }
            }
            ?>
        </div> 
    </div>
    <script>
        $(document).ready(function(){
            $(".btn-del").on('click', function(event) {
                var  form = $(this).find('form');
                var x = confirm("Remove this item to your cart?");
                if(x==true){
                    $.ajax({
                        type: 'POST',
                        url: 'deleteCart.php',
                        data: form.serialize(),
                        success: function () {
                            window.location.reload();
                        }
                    });
                } 
            });
            $(".bnt-add").on('click', function(e) {
                var  form = $(this).find('form');
                    $.ajax({
                        type: 'POST',
                        url: 'wishToCart.php',
                        data: form.serialize(),
                        complete: function(data){
                            if(data.responseText === "save\t"){
                                Swal.fire({ 
                                icon: 'success',  
                                title:'Online Shop',
                                text: 'Item has been added to your shopping cart',  
                                showConfirmButton: false,  
                                timer: 2000
                                }).then(()=>{
                                    window.location.href="cart.php";
                                });
                            } else if(data.responseText === "found\t"){
                                Swal.fire({ 
                                    icon:'info',
                                    title:'Online Shop',
                                    text: 'This product is already in your shopping cart .',  
                                    showConfirmButton: false,  
                                    timer: 2000
                                })
                            }
                    }   
                    });
                 
            });
        var formatter = new Intl.NumberFormat('en-PH', {
            style: 'currency',
            currency: 'PHP',
        });
        for(var i = 0 ; i < <?php echo $len_cart?> ; i++){
            $("#p"+i).html(formatter.format(parseInt($("#p"+i).html())));
            
        }
        
        });      
    </script>
</body>

</html>
