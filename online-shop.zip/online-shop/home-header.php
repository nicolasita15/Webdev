<?php
    session_start();
    if(empty($_SESSION["username"])) header("Location: index.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        html,body{
            margin:0;
            padding:0;
            box-sizing: border-box;
        }
    </style>
    <link rel="stylesheet" href="./products.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
     <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">  
</head>
<body>
<script>
       $(document).ready(function(){
            $("#result-search").hide();
            $("#search").keyup(function(){
                var str = $("#search").val();
                if (str.length==0) {
                    $("#result-search").html("");
                    $("#result-search").hide();
                    return;
                }
                var xmlhttp=new XMLHttpRequest();
                xmlhttp.onreadystatechange=function() {
                    if (this.readyState==4 && this.status==200) {
                        $("#result-search").html(this.responseText);
                        $("#result-search").show();
                       // $('.rs-item').html($("#result-search > form").length+" items");
                        console.log($('.rs-item').html());
                    }
                }
                xmlhttp.open("GET","live-search.php?prod="+str,true);
                xmlhttp.send();
            });
            $("#jjjrc").on('click',function(){
                window.location.href='home.php'
            });
        })
       
    </script>
    <div class="container-fluid">
        <div class="row px-5 py-2 bg-body">
            <div class="col-3">
                <button id='jjjrc' style="font-size:24px;" class="fw-bold p-1 m-0 btn-outline-info font-monospace btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    JJJRC
                </button>
            </div>
            <div class="col-5 d-grid pt-1">
                <form class="search">
                    <div class="input-group mb-3">
                        <input type="text" name="search" id="search" value="<?php echo (isset($_GET['prod_name'])) ? $_GET['prod_name'] : '';?>" class="form-control" placeholder="Search product here....">
                        <span class="fas fa-search input-group-text" id="basic-addon2"></span>
                    </div>
                </form>

                <div id="result-search">

                </div>
     
            </div>
            <div class="col-4  d-flex align-items-center justify-content-center">
                <a id="user" class='btn btn-outline-info fw-bold' href="transaction.php">
                    <i class="far fa-user me-2"></i>
                    <?php echo $_SESSION['username']?>
                </a>
            </div>
           
        </div>
        <div class="row bg-info py-3">
            <ul class="cos_ul"> 
                 <li><a class="<?php echo ($page == "item" ? "act" : "")?>" href="list.php">HOME</a></li>
                <li><a style='display:none;' class="<?php echo ($page == "home" ? "act" : "")?>" href="home.php">HOME</a></li>
                <li><a class="<?php echo ($page == "wishlist" ? "act" : "")?>"href="wish.php">WISHLIST</a></li>
    
                <li><a class="<?php echo ($page == "cart" ? "act" : "")?>" href="cart.php">ADD TO CART</a></li>
                <li ><a href="logout.php">LOGOUT</a></li>
            </ul>
        </div>

    </div>
    <script>
         $(document).ready(function(){
            var keys={};
            $("#user").addClass('btn-info-outline');
            $("#user").removeClass('btn-info text-white');

            $(document).keydown(function(e) {
                keys[e.which] = true;

                if (keys[18] && keys[72]) { // Ctrl + Alt + 1 in that order
                    Swal.fire({ 
                        showConfirmButton: false,  
                        timer: 500
                    }).then(()=>{
                        window.location.href="home.php";
                    });
                    Swal.showLoading();
                } else if(keys[18] && keys[87]){
                    Swal.fire({ 
                        showConfirmButton: false,  
                        timer: 500
                    }).then(()=>{
                        window.location.href="wish.php";
                    });
                    Swal.showLoading();
                }
                else if(keys[18] && keys[65]){
                    Swal.fire({ 
                        showConfirmButton: false,  
                        timer: 500
                    }).then(()=>{
                        window.location.href="cart.php";
                    });
                    Swal.showLoading();
                }
                else if(keys[18] && keys[76]){
                    Swal.fire({ 
                        showConfirmButton: false,  
                        timer: 500
                    }).then(()=>{
                        window.location.href="logout.php";
                    });
                    Swal.showLoading();
                }
                else if(keys[18] && keys[73]){
                    Swal.fire({ 
                        showConfirmButton: false,  
                        timer: 500
                    }).then(()=>{
                        window.location.href="list.php";
                    });
                    Swal.showLoading();
                }
                
                else if(keys[18] && keys[84]){
                    Swal.fire({ 
                        showConfirmButton: false,  
                        timer: 500
                    }).then(()=>{
                        window.location.href="transaction.php";
                    });
                    Swal.showLoading();
                }
                
            });

    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
