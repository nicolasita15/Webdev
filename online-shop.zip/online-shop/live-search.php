<?php

$xmlDoc=new DOMDocument();
$xmlDoc->load("admin/product.xml");

$x=$xmlDoc->getElementsByTagName('product');

$prod=$_GET["prod"];

if (strlen($prod)>0) {
  $hint="";
  for($i=0; $i<($x->length); $i++) {
    $y=$x->item($i)->getElementsByTagName('prod_name');
    $z=$x->item($i)->getElementsByTagName('prod_id');
    $img=$x->item($i)->getElementsByTagName('prod_path');
    
    if ($y->item(0)->nodeType==1) {
      if (stristr($y->item(0)->childNodes->item(0)->nodeValue,$prod)) {
        
          if ($hint=="") {
            $hint="
            <form action='viewProduct.php' method='get'>
            <input type='hidden' name='prod_id' value='". $z->item(0)->childNodes->item(0)->nodeValue ."'>
            <input type='hidden' name='prod_name' value='". $y->item(0)->childNodes->item(0)->nodeValue ."'>
            <div class='result-container'>
                <img src='".$img->item(0)->childNodes->item(0)->nodeValue ."' width='30'>
                <button style='font-size:12px;margin:0;padding:0;' type='submit'>" .$y->item(0)->childNodes->item(0)->nodeValue."</button>
              </div>
            </form>
            ";
          } else {
            $hint=$hint . "
        
            <form action='viewProduct.php' method='get'>
            <input type='hidden' name='prod_id' value='". $z->item(0)->childNodes->item(0)->nodeValue ."'>
            <input type='hidden' name='prod_name' value='". $y->item(0)->childNodes->item(0)->nodeValue ."'>
              <div class='result-container'>
                <img src='".$img->item(0)->childNodes->item(0)->nodeValue ."' width='30'>
                <button style='font-size:12px;margin:0;padding:0;' type='submit'>" .$y->item(0)->childNodes->item(0)->nodeValue."</button>
              </div>
            </form>";
          }
       
      }
    }
  }
}

// Set output to "no suggestion" if no hint was found
// or to the correct values
if ($hint=="") {
  $response="No result";
} else {
  $response=$hint;
}

//output the response
echo $response;

?>